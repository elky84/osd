﻿using System.Collections.Generic;
using System.Linq;
using HeroEditor.Common;
using UnityEngine;

namespace Assets.HeroEditor.FantasyInventory.Scripts
{
    public static class Extensions
    {
        //public static Sprite FindSprite(this List<SpriteGroupEntry> list, string path)
        //{
        //    var sprite = list.SingleOrDefault(i => i.Path == path)?.Sprite;

        //    if (sprite == null) Debug.LogWarning($"Sprite not found: {path}");

        //    return sprite;
        //}

        //public static List<Sprite> FindSprites(this List<SpriteGroupEntry> list, string path)
        //{
        //    var sprites = list.SingleOrDefault(i => i.Path == path)?.Sprites.ToList();

        //    if (sprites == null) Debug.LogWarning($"Sprites not found: {path}");

        //    return sprites;
        //}
    }
}