﻿namespace Assets.HeroEditor4D.SimpleColorPicker.Scripts
{
	/// <summary>
	/// Color mode.
	/// </summary>
	public enum ColorMode
	{
		Rgb,
		Hsv
	}
}